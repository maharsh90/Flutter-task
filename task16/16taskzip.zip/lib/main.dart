import 'package:flutter/material.dart';
import 'package:task16/task5_folder/bottom_bar_task5.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    //task1
    // home: ButtonDemo(),

    //task 2
    // home: WidgetLifecyclePage(),

    //task3
    // home: TaskThreeBottomPage(),

    //task 4
    // home: ColummnDesignDemoPage(),
    // home: ColumnRowDemo1(),
    // home: RowColumnPage(),

    //task 5
    home: BottomBar(),

    //task 6
    // home: ListDesignPage(),
  ));
}
