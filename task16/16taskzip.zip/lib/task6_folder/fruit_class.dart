class Fruit {
  late String img;
  late String name;
  late String subtitle;
  late String dt;

  Fruit(this.img, this.name, this.subtitle, this.dt);
}
