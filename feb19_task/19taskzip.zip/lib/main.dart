import 'package:feb19_task/task2_folder/task2_design6.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    //task 2
    //first screen
    // home: TopOfEachPage1(),

    //second screen
    // home: TopOfEachPage2(),

    //third screen
    // home: TopOfEachPage3(),

    //fourth screen
    // home: TopOfEachPage4(),

    //fifth screen
    // home: TopOfEachPage5(),

    //sixth screen
    home: TopOfEachPage6(),

    //seven screen
    // home: TopOfEachPage7(),

    //eight screen
    // home: TopOfEachPage8(),
  ));
}
