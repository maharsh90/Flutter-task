import 'package:flutter/material.dart';
import 'package:task23/category_all.dart';

class CategoriesPage extends StatefulWidget {
  const CategoriesPage({super.key});

  @override
  State<CategoriesPage> createState() => _CategoriesPageState();
}

class _CategoriesPageState extends State<CategoriesPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: DefaultTabController(
          length: 4,
          child: Column(
            children: [
              const Padding(
                padding: EdgeInsets.all(18.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    "Mechanical Keyboard",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                  ),
                ),
              ),
              SizedBox(
                height: 50,
                child: TabBar(
                  indicator: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black),
                  unselectedLabelColor: Colors.black,
                  labelColor: Colors.white,
                  indicatorColor: Colors.red,
                  tabs: [
                    Container(
                      width: 60,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.black),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Tab(
                        text: 'All',
                      ),
                    ),
                    Container(
                      width: 60,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.black),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Tab(
                        text: 'Razor',
                      ),
                    ),
                    Container(
                      width: 60,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.black),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Tab(
                        text: 'HP',
                      ),
                    ),
                    Container(
                      width: 60,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.black),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Tab(
                        text: 'Asus',
                      ),
                    ),
                  ],
                ),
              ),
              const Expanded(
                child: TabBarView(children: [
                  //tab1
                  CategoryAllPage(),
                  //tab2
                  Center(child: Text('hi')),
                  //tab3
                  Center(child: Text('hi')),
                  //tab4
                  Center(child: Text('hi')),
                ]),
              )
            ],
          ),
        ),
      ),
    );
  }
}
