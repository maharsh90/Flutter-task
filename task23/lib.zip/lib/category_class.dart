class Category {
  String imag;
  String des;
  String price;

  Category(this.imag, this.des, this.price);
}
