import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:task23/task1_drawer.dart';

void main() {
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.red,
      statusBarIconBrightness: Brightness.dark,
      statusBarBrightness: Brightness.dark,
    ),
  );

  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: DrawerTask1(),
  ));
}
