import 'package:feb15_task/mode_task1.dart';
import 'package:feb15_task/theme/theme.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    theme: lightMode,
    debugShowCheckedModeBanner: false,
    home: ChangeMode(),
  ));
}
