import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      //task1 screen1
      // home: Task1Screen1(),

      //task1 screen2
      // home: Task1_Screen2(),

      //task1 screen3
      // home: Task1Screen3(),
    ),
  );
}
