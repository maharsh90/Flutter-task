import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
      //task 1 screen1
      // home: Task1Screen1(),

      //task1 screen2
      // home: Task1Screen2(),

      //task1 screen3
      // home: Task1Screen3(),

      //task2 screen1
      // home: Task2Screen1(),

      //tas2 screen2
      // home: Task2Screen2(),
      ));
}
